from django.shortcuts import render

# Create your views here.
def log(request):
    return render(request,"login.html")

def regi(request):
    return render(request,"registra.html")
